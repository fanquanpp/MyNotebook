<a id="title"></a>
# Java 标识符

> fanquanpp 的个人学习笔记

最新更新时间：2026-04-05 22:00:00

<a id="1"></a>
## 1 引言

标识符是 Java 中用于命名变量、方法、类等元素的名称，遵循一定的命名规则和规范。

<a id="2"></a>
## 2 目录

- [1. 标识符的组成](#1-标识符的组成)
- [2. 标识符的命名规则](#2-标识符的命名规则)
- [3. 命名规范](#3-命名规范)
- [4. 关键字](#4-关键字)
- [5. 常见问题与解决方案](#5-常见问题与解决方案)
- [6. 总结与最佳实践](#6-总结与最佳实践)

<a id="3"></a>
## 3 . 标识符的组成

<a id="3.1"></a>
### 3.1 组成元素

标识符由以下元素组成：
- 字母（a-z, A-Z）
- 数字（0-9）
- 下划线（_）
- 美元符号（$）

**注意：** 标识符不能以数字开头。

<a id="3.2"></a>
### 3.2 示例

**合法标识符：**
- `name`
- `age123`
- `_score`
- `$salary`
- `firstName`

**非法标识符：**
- `123abc`（以数字开头）
- `first-name`（包含连字符）
- `class`（关键字）
- `int`（关键字）

<a id="4"></a>
## 4 . 标识符的命名规则

<a id="4.1"></a>
### 4.1 硬性要求

1. 由数字、字母、下划线、$ 组成
2. 不能以数字开头
3. 不能使用关键字作为标识符
4. 不能使用系统定义的常量、函数、类型等作为标识符
5. 区分大小写

<a id="4.2"></a>
### 4.2 示例

**违反规则的示例：**
- `123test`：以数字开头
- `my-class`：包含连字符
- `public`：使用关键字
- `true`：使用常量

<a id="5"></a>
## 5 . 命名规范

<a id="5.1"></a>
### 5.1 小驼峰命名法（方法、变量等）

**规范：**
- 标识符是一个单词时，全部小写
    - 例：`name`、`age`、`score`
- 标识符由多个单词组成时，第一个单词全部小写，其他单词的首字母大写
    - 例：`firstName`、`lastName`、`getAge`

**示例：**

```java
int age = 18;
String firstName = "John";
double calculateSalary() {
    // 方法体
}
```

<a id="5.2"></a>
### 5.2 大驼峰命名法（类名、接口名、枚举名等）

**规范：**
- 标识符是一个单词时，首字母大写
    - 例：`Student`、`Person`、`Car`
- 标识符由多个单词组成时，每个单词首字母大写
    - 例：`FirstName`、`LastName`、`CalculateSalary`

**示例：**

```java
public class Student {
    // 类体
}

public interface Runnable {
    // 接口体
}

public enum Color {
    // 枚举体
}
```

<a id="5.3"></a>
### 5.3 常量命名规范

**规范：**
- 全部大写
- 单词间用下划线分隔
- 见名知意

**示例：**

```java
public static final int MAX_AGE = 100;
public static final double PI = 3.1415926;
public static final String SCHOOL_NAME = "北京大学";
```

<a id="5.4"></a>
### 5.4 包名命名规范

**规范：**
- 全部小写
- 域名倒写作为前缀
- 单词间用点分隔

**示例：**

```java
package com.example.demo;
package org.apache.commons.lang;
```

<a id="6"></a>
## 6 . 关键字

<a id="6.1"></a>
### 6.1 关键字列表

```
abstract   continue   for   new   switch
assert     default    goto   package   synchronized
boolean    do         if     private   this
break      double     implements  protected   throw
byte       else       import    public     throws
case       enum       instanceof  return   transient
catch      extends    int     short     try
char       final      interface  static     void
class      finally    long     strictfp  volatile
const      float      native    super     while
```

<a id="6.2"></a>
### 6.2 关键字说明

- **abstract**：抽象类或方法
- **final**：最终类、方法或变量
- **static**：静态成员
- **public**、**private**、**protected**：访问修饰符
- **class**：类定义
- **interface**：接口定义
- **enum**：枚举定义
- **extends**：继承
- **implements**：实现接口
- **if**、**else**、**switch**、**case**：条件语句
- **for**、**while**、**do**：循环语句
- **try**、**catch**、**finally**：异常处理
- **return**、**break**、**continue**：跳转语句

<a id="7"></a>
## 7 . 常见问题与解决方案

<a id="7.1"></a>
### 7.1 命名冲突

**问题描述：** 标识符与关键字或系统保留字冲突。

**解决方案：**
- 避免使用关键字作为标识符
- 如果必须使用类似名称，可以添加后缀或前缀
    - 例如：`class` → `className`

<a id="7.2"></a>
### 7.2 命名不规范

**问题描述：** 标识符命名不符合规范，影响代码可读性。

**解决方案：**
- 遵循小驼峰或大驼峰命名法
- 使用有意义的名称，见名知意
- 避免使用单个字母作为变量名（除了临时变量）

<a id="7.3"></a>
### 7.3 大小写错误

**问题描述：** 标识符大小写使用错误，导致编译错误或运行时错误。

**解决方案：**
- 注意 Java 是大小写敏感的语言
- 保持一致的大小写风格
- 使用 IDE 的自动补全功能减少错误

<a id="8"></a>
## 8 . 总结与最佳实践

<a id="8.1"></a>
### 8.1 核心概念

- **标识符**：用于命名变量、方法、类等元素的名称
- **命名规则**：由字母、数字、下划线、$ 组成，不能以数字开头
- **命名规范**：小驼峰、大驼峰、常量命名规范
- **关键字**：Java 保留的特殊单词

<a id="8.2"></a>
### 8.2 最佳实践

1. **命名原则**
   - 见名知意：使用能表达含义的名称
   - 简洁明了：避免过长的标识符
   - 一致性：保持命名风格一致

2. **具体规范**
   - 类名：大驼峰命名法
   - 方法名：小驼峰命名法
   - 变量名：小驼峰命名法
   - 常量名：全大写，下划线分隔
   - 包名：全小写，域名倒写

3. **命名技巧**
   - 使用动词开头命名方法：`getAge()`、`setName()`
   - 使用名词命名类和变量：`Student`、`name`
   - 使用形容词命名布尔变量：`isActive`、`hasPermission`

<a id="8.3"></a>
### 8.3 个人实践总结
- 遵循 Java 标识符命名规则和规范
- 使用有意义的名称，提高代码可读性
- 保持命名风格一致
- 避免使用关键字和保留字
- 合理使用大小写，注意 Java 的大小写敏感性