<a id="title"></a>
# Java 核心知识点

<a id="1"></a>
## 1 . Java 概述

Java 是一种面向对象的编程语言，由 Sun Microsystems（现在是 Oracle）于 1995 年发布。它的设计理念是"Write Once, Run Anywhere"（一次编写，到处运行），通过 Java 虚拟机（JVM）实现跨平台特性。

<a id="1.1"></a>
### 1.1 Java 的核心特点
- **跨平台性**：通过 JVM 实现"一次编写，到处运行"
- **面向对象**：支持封装、继承、多态等面向对象特性
- **强类型语言**：编译时类型检查
- **自动内存管理**：垃圾回收机制，减少内存泄漏
- **丰富的标准库**：提供大量实用工具类
- **安全性**：内置安全机制，防止恶意代码
- **多线程**：支持多线程编程

<a id="1.2"></a>
### 1.2 Java 的应用领域
- **企业级应用**：大型企业系统、ERP、CRM 等
- **移动应用**：Android 应用开发
- **Web 应用**：Java EE、Spring 框架等
- **嵌入式系统**：智能设备、物联网设备
- **大数据**：Hadoop、Spark 等
- **云计算**：云服务、微服务架构

<a id="2"></a>
## 2 . Java 开发环境

<a id="2.1"></a>
### 2.1 JDK、JRE 和 JVM

- **JDK（Java Development Kit）**：Java 开发工具包，包含 JRE 和开发工具
- **JRE（Java Runtime Environment）**：Java 运行时环境，包含 JVM 和核心类库
- **JVM（Java Virtual Machine）**：Java 虚拟机，负责执行 Java 字节码

<a id="2.2"></a>
### 2.2 安装 JDK

1. **下载 JDK**：从 Oracle 官网或 OpenJDK 官网下载适合操作系统的 JDK 版本
2. **安装 JDK**：运行安装程序，按照提示完成安装
3. **配置环境变量**：
   - `JAVA_HOME`：指向 JDK 安装目录
   - `PATH`：添加`%JAVA_HOME%\bin`（Windows）或`$JAVA_HOME/bin`（Linux/Mac）
4. **验证安装**：运行`java -version`和`javac -version`命令

<a id="2.3"></a>
### 2.3 开发工具

- **Eclipse**：开源的集成开发环境
- **IntelliJ IDEA**：功能强大的商业 IDE，有社区版
- **NetBeans**：开源的集成开发环境
- **VSCode**：轻量级编辑器，需要安装 Java 插件

<a id="3"></a>
## 3 . Java 基础语法

<a id="3.1"></a>
### 3.1 基本结构

```java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```

**说明**：
- `public class HelloWorld`：定义一个公共类，类名必须与文件名相同
- `public static void main(String[] args)`：主方法，程序的入口点
- `System.out.println("Hello, World!")`：输出语句

<a id="3.2"></a>
### 3.2 注释

```java
// 单行注释

/*
 * 多行注释
 */

/**
 * 文档注释
 * @author 作者
 * @version 版本
 */
```

<a id="3.3"></a>
### 3.3 标识符

- **命名规则**：
    - 由字母、数字、下划线和美元符号组成
    - 不能以数字开头
    - 不能使用关键字和保留字
    - 区分大小写

- **命名规范**：
    - 类名：大驼峰命名法，如`HelloWorld`
    - 方法名和变量名：小驼峰命名法，如`getUserName`
    - 常量：全大写，单词间用下划线分隔，如`MAX_VALUE`
    - 包名：小写字母，如`com.example`

<a id="3.4"></a>
### 3.4 关键字

```
abstract   continue   for   new   switch
assert     default    goto   package   synchronized
boolean    do         if     private   this
break      double     implements  protected   throw
byte       else       import    public     throws
case       enum       instanceof  return   transient
catch      extends    int     short     try
char       final      interface  static     void
class      finally    long     strictfp  volatile
const      float      native    super     while
```

<a id="4"></a>
## 4 . 数据类型

<a id="4.1"></a>
### 4.1 基本数据类型

| 数据类型 | 关键字 | 占用字节 | 取值范围 | 默认值 |
| :------- | :----- | :------- | :------- | :----- |
| 字节型 | `byte` | 1 | -128~127 | 0 |
| 短整型 | `short` | 2 | -32768~32767 | 0 |
| 整型 | `int` | 4 | -2147483648~2147483647 | 0 |
| 长整型 | `long` | 8 | -9223372036854775808~9223372036854775807 | 0L |
| 单精度浮点型 | `float` | 4 | -3.4028235E+38~3.4028235E+38 | 0.0f |
| 双精度浮点型 | `double` | 8 | -1.7976931348623157E+308~1.7976931348623157E+308 | 0.0d |
| 字符型 | `char` | 2 | '\u0000'~'\uffff' | '\u0000' |
| 布尔型 | `boolean` | 1 | true/false | false |

<a id="4.2"></a>
### 4.2 引用数据类型

- **类（Class）**：如`String`、`Integer`等
- **接口（Interface）**：如`List`、`Map`等
- **数组（Array）**：如`int[]`、`String[]`等

<a id="4.3"></a>
### 4.3 类型转换

- **自动类型转换**：小范围类型向大范围类型转换
  ```java
  byte b = 10;
  int i = b; // 自动转换
  ```

- **强制类型转换**：大范围类型向小范围类型转换
  ```java
  int i = 100;
  byte b = (byte) i; // 强制转换
  ```

<a id="5"></a>
## 5 . 变量与常量

<a id="5.1"></a>
### 5.1 变量

```java
// 声明变量
数据类型 变量名;

// 声明并初始化
数据类型 变量名 = 值;

// 示例
int age = 18;
double salary = 5000.50;
String name = "张三";
```

<a id="5.2"></a>
### 5.2 常量

```java
// 声明常量
final 数据类型 常量名 = 值;

// 示例
final int MAX_AGE = 100;
final double PI = 3.1415926;
final String SCHOOL_NAME = "北京大学";
```

<a id="5.3"></a>
### 5.3 作用域

- **局部变量**：在方法或代码块中定义，仅在该范围内有效
- **成员变量**：在类中定义，在整个类中有效
- **静态变量**：使用`static`修饰，在整个类中有效，属于类的共享资源

<a id="6"></a>
## 6 . 运算符

<a id="6.1"></a>
### 6.1 算术运算符

| 运算符 | 描述 | 示例 |
| :----- | :--- | :--- |
| `+` | 加 | `a + b` |
| `-` | 减 | `a - b` |
| `*` | 乘 | `a * b` |
| `/` | 除 | `a / b` |
| `%` | 取余 | `a % b` |
| `++` | 自增 | `i++` 或 `++i` |
| `--` | 自减 | `i--` 或 `--i` |

<a id="6.2"></a>
### 6.2 关系运算符

| 运算符 | 描述 | 示例 |
| :----- | :--- | :--- |
| `>` | 大于 | `a > b` |
| `<` | 小于 | `a < b` |
| `>=` | 大于等于 | `a >= b` |
| `<=` | 小于等于 | `a <= b` |
| `==` | 等于 | `a == b` |
| `!=` | 不等于 | `a != b` |

<a id="6.3"></a>
### 6.3 逻辑运算符

| 运算符 | 描述 | 示例 |
| :----- | :--- | :--- |
| `&&` | 逻辑与 | `a && b` |
| `||` | 逻辑或 | `a || b` |
| `!` | 逻辑非 | `!a` |

<a id="6.4"></a>
### 6.4 赋值运算符

| 运算符 | 描述 | 示例 |
| :----- | :--- | :--- |
| `=` | 赋值 | `a = b` |
| `+=` | 累加 | `a += b` 等价于 `a = a + b` |
| `-=` | 累减 | `a -= b` 等价于 `a = a - b` |
| `*=` | 累乘 | `a *= b` 等价于 `a = a * b` |
| `/=` | 累除 | `a /= b` 等价于 `a = a / b` |
| `%=` | 取余赋值 | `a %= b` 等价于 `a = a % b` |

<a id="6.5"></a>
### 6.5 三元运算符

```java
// 格式：条件表达式 ? 表达式 1 : 表达式 2
int max = (a > b) ? a : b;
```

<a id="7"></a>
## 7 . 流程控制

<a id="7.1"></a>
### 7.1 条件语句

<a id="7.1.1"></a>
#### 7.1.1 if 语句

```java
// 基本 if 语句
if (条件) {
    // 条件为真时执行
}

// if-else 语句
if (条件) {
    // 条件为真时执行
} else {
    // 条件为假时执行
}

// if-else if-else 语句
if (条件 1) {
    // 条件 1 为真时执行
} else if (条件 2) {
    // 条件 2 为真时执行
} else {
    // 所有条件都为假时执行
}
```

<a id="7.1.2"></a>
#### 7.1.2 switch 语句

```java
switch (表达式) {
    case 值 1:
        // 表达式等于值 1 时执行
        break;
    case 值 2:
        // 表达式等于值 2 时执行
        break;
    // 更多 case
    default:
        // 表达式不等于任何 case 值时执行
        break;
}
```

<a id="7.2"></a>
### 7.2 循环语句

<a id="7.2.1"></a>
#### 7.2.1 for 循环

```java
for (初始化语句; 循环条件; 步进语句) {
    // 循环体
}

// 示例
for (int i = 0; i < 10; i++) {
    System.out.println(i);
}
```

<a id="7.2.2"></a>
#### 7.2.2 while 循环

```java
while (循环条件) {
    // 循环体
}

// 示例
int i = 0;
while (i < 10) {
    System.out.println(i);
    i++;
}
```

<a id="7.2.3"></a>
#### 7.2.3 do-while 循环

```java
do {
    // 循环体
} while (循环条件);

// 示例
int i = 0;
do {
    System.out.println(i);
    i++;
} while (i < 10);
```

<a id="7.3"></a>
### 7.3 跳转语句

- **break**：终止当前循环或 switch 语句
- **continue**：跳过当前循环的剩余部分，开始下一次循环
- **return**：从当前方法返回，结束方法的执行

<a id="8"></a>
## 8 . 数组

<a id="8.1"></a>
### 8.1 数组的定义

```java
// 静态初始化
数据类型[] 数组名 = {元素 1, 元素 2, ...};

// 动态初始化
数据类型[] 数组名 = new 数据类型[数组长度];

// 示例
int[] arr1 = {1, 2, 3, 4, 5};
int[] arr2 = new int[5];
```

<a id="8.2"></a>
### 8.2 数组的访问

```java
// 访问数组元素
数组名[索引];

// 修改数组元素
数组名[索引] = 值;

// 获取数组长度
数组名.length;

// 示例
int[] arr = {1, 2, 3, 4, 5};
System.out.println(arr[0]); // 输出 1
arr[0] = 10;
System.out.println(arr[0]); // 输出 10
System.out.println(arr.length); // 输出 5
```

<a id="8.3"></a>
### 8.3 数组的遍历

```java
// 使用 for 循环遍历
for (int i = 0; i < arr.length; i++) {
    System.out.println(arr[i]);
}

// 使用增强 for 循环遍历
for (int element : arr) {
    System.out.println(element);
}
```

<a id="8.4"></a>
### 8.4 二维数组

```java
// 静态初始化
数据类型[][] 数组名 = {
    {元素 1, 元素 2, ...},
    {元素 3, 元素 4, ...},
    ...
};

// 动态初始化
数据类型[][] 数组名 = new 数据类型[行数][列数];

// 示例
int[][] arr = {
    {1, 2, 3},
    {4, 5, 6}
};

// 访问二维数组元素
System.out.println(arr[0][0]); // 输出 1

// 遍历二维数组
for (int i = 0; i < arr.length; i++) {
    for (int j = 0; j < arr[i].length; j++) {
        System.out.print(arr[i][j] + " ");
    }
    System.out.println();
}
```

<a id="9"></a>
## 9 . 方法

<a id="9.1"></a>
### 9.1 方法的定义

```java
修饰符 返回值类型 方法名(参数列表) {
    // 方法体
    return 返回值; // 可选，void 类型不需要
}

// 示例
public int add(int a, int b) {
    int sum = a + b;
    return sum;
}
```

<a id="9.2"></a>
### 9.2 方法的调用

```java
// 调用方法
方法名(参数列表);

// 示例
int result = add(10, 20);
System.out.println(result); // 输出 30
```

<a id="9.3"></a>
### 9.3 方法的重载

方法重载是指在同一个类中，方法名相同但参数列表不同的方法。

```java
// 示例
public int add(int a, int b) {
    return a + b;
}

public double add(double a, double b) {
    return a + b;
}

public int add(int a, int b, int c) {
    return a + b + c;
}
```

<a id="9.4"></a>
### 9.4 递归方法

递归方法是指方法调用自身的方法。

```java
// 示例：计算阶乘
public int factorial(int n) {
    if (n <= 1) {
        return 1; // 终止条件
    }
    return n * factorial(n - 1);
}
```

<a id="10"></a>
## 10 . 面向对象编程

<a id="10.1"></a>
### 10.1 类与对象

- **类**：是对象的模板，定义了对象的属性和方法
- **对象**：是类的实例，具有类定义的属性和方法

```java
// 定义类
public class Person {
    // 属性
    private String name;
    private int age;
    
    // 构造方法
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    // 方法
    public void sayHello() {
        System.out.println("Hello, my name is " + name + ", I'm " + age + " years old.");
    }
    
    // getter 和 setter 方法
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
}

// 创建对象
Person person = new Person("张三", 18);
person.sayHello(); // 输出：Hello, my name is 张三, I'm 18 years old.
```

<a id="10.2"></a>
### 10.2 封装

封装是指将对象的属性和方法封装起来，只对外提供公共的访问方式。

```java
public class Student {
    // 私有属性
    private String name;
    private int score;
    
    // 公共方法
    public void setScore(int score) {
        if (score >= 0 && score <= 100) {
            this.score = score;
        } else {
            System.out.println("分数必须在 0-100 之间");
        }
    }
    
    public int getScore() {
        return score;
    }
}
```

<a id="10.3"></a>
### 10.3 继承

继承是指一个类继承另一个类的属性和方法。

```java
// 父类
public class Animal {
    public void eat() {
        System.out.println("动物在吃东西");
    }
}

// 子类
public class Dog extends Animal {
    @Override
    public void eat() {
        System.out.println("狗在吃骨头");
    }
    
    public void bark() {
        System.out.println("狗在汪汪叫");
    }
}
```

<a id="10.4"></a>
### 10.4 多态

多态是指同一方法在不同对象上有不同的表现形式。

```java
Animal animal1 = new Animal();
animal1.eat(); // 输出：动物在吃东西

Animal animal2 = new Dog();
animal2.eat(); // 输出：狗在吃骨头
```

<a id="10.5"></a>
### 10.5 抽象类与接口

- **抽象类**：包含抽象方法的类，不能实例化
- **接口**：定义方法签名的集合，不能包含实现

```java
// 抽象类
abstract class Shape {
    abstract void draw();
}

// 接口
interface Flyable {
    void fly();
}

// 实现类
class Circle extends Shape implements Flyable {
    @Override
    void draw() {
        System.out.println("画圆形");
    }
    
    @Override
    public void fly() {
        System.out.println("圆形在飞");
    }
}
```

<a id="11"></a>
## 11 . 异常处理

<a id="11.1"></a>
### 11.1 异常的分类

- **检查型异常**：编译时检查的异常，必须处理
- **非检查型异常**：运行时异常，不需要显式处理

<a id="11.2"></a>
### 11.2 异常处理机制

```java
try {
    // 可能抛出异常的代码
} catch (Exception e) {
    // 处理异常
    e.printStackTrace();
} finally {
    // 无论是否发生异常都会执行的代码
}
```

<a id="11.3"></a>
### 11.3 自定义异常

```java
// 自定义异常
class MyException extends Exception {
    public MyException(String message) {
        super(message);
    }
}

// 抛出自定义异常
public void test() throws MyException {
    throw new MyException("自定义异常");
}
```

<a id="12"></a>
## 12 . 输入输出

<a id="12.1"></a>
### 12.1 控制台输入

```java
import java.util.Scanner;

public class InputExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("请输入姓名：");
        String name = scanner.next();
        
        System.out.print("请输入年龄：");
        int age = scanner.nextInt();
        
        System.out.println("姓名：" + name + "，年龄：" + age);
        
        scanner.close();
    }
}
```

<a id="12.2"></a>
### 12.2 文件操作

```java
import java.io.*;

public class FileExample {
    public static void main(String[] args) {
        // 写入文件
        try (PrintWriter writer = new PrintWriter(new FileWriter("test.txt"))) {
            writer.println("Hello, World!");
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // 读取文件
        try (BufferedReader reader = new BufferedReader(new FileReader("test.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
```

<a id="13"></a>
## 13 . 集合框架

<a id="13.1"></a>
### 13.1 常用集合

- **List**：有序集合，允许重复元素
    - `ArrayList`：基于数组的实现
    - `LinkedList`：基于链表的实现

- **Set**：无序集合，不允许重复元素
    - `HashSet`：基于哈希表的实现
    - `TreeSet`：基于红黑树的实现

- **Map**：键值对集合
    - `HashMap`：基于哈希表的实现
    - `TreeMap`：基于红黑树的实现

<a id="13.2"></a>
### 13.2 集合的使用

```java
import java.util.*;

public class CollectionExample {
    public static void main(String[] args) {
        // List
        List<String> list = new ArrayList<>();
        list.add("张三");
        list.add("李四");
        list.add("王五");
        System.out.println(list); // 输出：[张三, 李四, 王五]
        
        // Set
        Set<String> set = new HashSet<>();
        set.add("张三");
        set.add("李四");
        set.add("张三"); // 重复元素，不会添加
        System.out.println(set); // 输出：[张三, 李四]
        
        // Map
        Map<String, Integer> map = new HashMap<>();
        map.put("张三", 18);
        map.put("李四", 20);
        System.out.println(map); // 输出：{张三=18, 李四=20}
        System.out.println(map.get("张三")); // 输出：18
    }
}
```

<a id="14"></a>
## 14 . 多线程

<a id="14.1"></a>
### 14.1 线程的创建

```java
// 继承 Thread 类
class MyThread extends Thread {
    @Override
    public void run() {
        System.out.println("线程执行");
    }
}

// 实现 Runnable 接口
class MyRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("线程执行");
    }
}

// 使用
public class ThreadExample {
    public static void main(String[] args) {
        // 方式 1
        MyThread thread1 = new MyThread();
        thread1.start();
        
        // 方式 2
        MyRunnable runnable = new MyRunnable();
        Thread thread2 = new Thread(runnable);
        thread2.start();
        
        // 方式 3：使用 lambda 表达式
        Thread thread3 = new Thread(() -> {
            System.out.println("线程执行");
        });
        thread3.start();
    }
}
```

<a id="14.2"></a>
### 14.2 线程同步

```java
public class SynchronizedExample {
    private static int count = 0;
    private static final Object lock = new Object();
    
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            new Thread(() -> {
                synchronized (lock) {
                    for (int j = 0; j < 1000; j++) {
                        count++;
                    }
                }
            }).start();
        }
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("count: " + count);
    }
}
```

<a id="15"></a>
## 15 . 总结

Java 是一种功能强大的编程语言，具有跨平台、面向对象、安全稳定等特点。通过掌握 Java 的核心知识点，你可以开发各种类型的应用程序，从简单的控制台应用到复杂的企业级系统。

<a id="15.1"></a>
### 15.1 核心要点

- **基础语法**：变量、数据类型、运算符、流程控制
- **面向对象**：类与对象、封装、继承、多态
- **异常处理**：try-catch-finally、自定义异常
- **集合框架**：List、Set、Map 等
- **输入输出**：控制台输入、文件操作
- **多线程**：线程创建、线程同步

<a id="15.2"></a>
### 15.2 学习建议

- **实践**：通过实际项目练习 Java 编程
- **理解**：掌握 Java 的核心概念和原理
- **规范**：遵循 Java 编码规范
- **持续学习**：关注 Java 的新特性和发展
- **阅读源码**：学习优秀的 Java 代码

通过不断学习和实践，你将能够熟练使用 Java，开发出更加优秀的应用程序。