<a id="title"></a>
# Java 方法

> fanquanpp 的个人学习笔记

最新更新时间：2026-04-05 22:00:00

<a id="1"></a>
## 1 引言

方法是 Java 中实现代码复用的核心机制，通过将重复的业务逻辑封装成独立单元，实现一次定义、多次调用。

<a id="2"></a>
## 2 目录

- [1. 方法的定义与结构](#1-方法的定义与结构)
- [2. 方法的调用](#2-方法的调用)
- [3. 方法重载](#3-方法重载)
- [4. 方法的参数传递](#4-方法的参数传递)
- [5. 方法的返回值](#5-方法的返回值)
- [6. 静态方法与实例方法](#6-静态方法与实例方法)
- [7. 方法的作用域](#7-方法的作用域)
- [8. 常见问题与解决方案](#8-常见问题与解决方案)
- [9. 最佳实践](#9-最佳实践)
- [10. 总结](#10-总结)

<a id="3"></a>
## 3 . 方法的定义与结构

<a id="3.1"></a>
### 3.1 方法的基本结构

```java
访问修饰符 返回值类型 方法名(参数列表) {
    // 方法体
    return 返回值; // 可选，void 类型不需要
}
```

- **访问修饰符**：控制方法的访问权限，常用的有 public、private、protected
- **返回值类型**：方法执行后返回的数据类型，无返回值时使用 void
- **方法名**：遵循小驼峰命名法，见名知意
- **参数列表**：方法接收的输入参数，格式为"数据类型 参数名"
- **方法体**：实现方法功能的代码块
- **return 语句**：返回方法的结果，void 类型方法可以省略

<a id="3.2"></a>
### 3.2 方法定义示例

```java
// 无参数无返回值的方法
public void printHello() {
    System.out.println("Hello, World!");
}

// 有参数无返回值的方法
public void printMessage(String message) {
    System.out.println(message);
}

// 有参数有返回值的方法
public int add(int a, int b) {
    return a + b;
}

// 多个参数的方法
public double calculateArea(double length, double width) {
    return length * width;
}
```

<a id="4"></a>
## 4 . 方法的调用

<a id="4.1"></a>
### 4.1 实例方法的调用

实例方法需要通过对象来调用：

```java
// 1. 创建对象
ClassName obj = new ClassName();
// 2. 调用方法
obj.methodName(参数);
```

**示例：**

```java
public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
}

// 调用方法
Calculator calculator = new Calculator();
int result = calculator.add(5, 3);
System.out.println("结果：" + result); // 输出：结果：8
```

<a id="4.2"></a>
### 4.2 静态方法的调用

静态方法可以直接通过类名调用：

```java
ClassName.methodName(参数);
```

**示例：**

```java
public class MathUtil {
    public static int max(int a, int b) {
        return a > b ? a : b;
    }
}

// 调用方法
int maxValue = MathUtil.max(10, 20);
System.out.println("最大值：" + maxValue); // 输出：最大值：20
```

<a id="5"></a>
## 5 . 方法重载

<a id="5.1"></a>
### 5.1 方法重载的概念

方法重载是指在同一个类中，定义多个同名方法，但参数列表不同的现象。

<a id="5.2"></a>
### 5.2 方法重载的规则

- **必须在同一个类中**
- **方法名必须相同**
- **参数列表必须不同**（满足其一即可）：
    - 参数个数不同
    - 参数类型不同
    - 参数顺序不同
- **与返回值类型无关**
- **与访问修饰符无关**

<a id="5.3"></a>
### 5.3 方法重载示例

```java
public class Calculator {
    // 两个整数相加
    public int add(int a, int b) {
        return a + b;
    }
    
    // 三个整数相加
    public int add(int a, int b, int c) {
        return a + b + c;
    }
    
    // 两个小数相加
    public double add(double a, double b) {
        return a + b;
    }
    
    // 整数和小数相加
    public double add(int a, double b) {
        return a + b;
    }
    
    // 小数和整数相加（参数顺序不同）
    public double add(double a, int b) {
        return a + b;
    }
}
```

<a id="5.4"></a>
### 5.4 方法重载的应用场景

- **提高代码可读性**：使用相同的方法名表示相同的功能
- **方便用户使用**：用户可以根据不同的参数类型调用相应的方法
- **实现多态**：在编译时根据参数类型确定调用哪个方法

<a id="6"></a>
## 6 . 方法的参数传递

<a id="6.1"></a>
### 6.1 值传递

Java 中所有参数传递都是值传递，即传递的是参数的副本。

- **基本数据类型**：传递的是值的副本，修改参数不会影响原始值
- **引用数据类型**：传递的是引用的副本，修改引用指向的对象会影响原始对象

<a id="6.2"></a>
### 6.2 参数传递示例

```java
// 基本数据类型参数
public void modifyValue(int value) {
    value = 100;
    System.out.println("方法内：" + value); // 输出：方法内：100
}

// 引用数据类型参数
public void modifyArray(int[] arr) {
    arr[0] = 100;
    System.out.println("方法内：" + arr[0]); // 输出：方法内：100
}

// 调用示例
int num = 10;
modifyValue(num);
System.out.println("方法外：" + num); // 输出：方法外：10

int[] array = {1, 2, 3};
modifyArray(array);
System.out.println("方法外：" + array[0]); // 输出：方法外：100
```

<a id="7"></a>
## 7 . 方法的返回值

<a id="7.1"></a>
### 7.1 返回值类型

- **基本数据类型**：int、double、boolean 等
- **引用数据类型**：String、数组、对象等
- **void**：无返回值

<a id="7.2"></a>
### 7.2 return 语句

- **有返回值的方法**：必须使用 return 语句返回对应类型的值
- **void 方法**：可以使用 return 语句提前结束方法，也可以省略

<a id="7.3"></a>
### 7.3 返回值示例

```java
// 返回基本数据类型
public int getMax(int a, int b) {
    return a > b ? a : b;
}

// 返回引用数据类型
public String getGreeting(String name) {
    return "Hello, " + name + "!";
}

// 返回数组
public int[] createArray(int size) {
    int[] arr = new int[size];
    for (int i = 0; i < size; i++) {
        arr[i] = i + 1;
    }
    return arr;
}

// void 方法
public void printArray(int[] arr) {
    if (arr == null || arr.length == 0) {
        return; // 提前结束方法
    }
    for (int num : arr) {
        System.out.print(num + " ");
    }
    System.out.println();
}
```

<a id="8"></a>
## 8 . 静态方法与实例方法

<a id="8.1"></a>
### 8.1 静态方法

- 使用 static 修饰
- 属于类，不属于对象
- 可以直接通过类名调用
- 不能访问实例变量和实例方法
- 可以访问静态变量和静态方法

<a id="8.2"></a>
### 8.2 实例方法

- 不使用 static 修饰
- 属于对象
- 需要通过对象调用
- 可以访问实例变量和实例方法
- 可以访问静态变量和静态方法

<a id="8.3"></a>
### 8.3 静态方法与实例方法示例

```java
public class Counter {
    // 静态变量
    private static int staticCount = 0;
    // 实例变量
    private int instanceCount = 0;
    
    // 静态方法
    public static void incrementStatic() {
        staticCount++;
        // instanceCount++; // 编译错误，静态方法不能访问实例变量
    }
    
    // 实例方法
    public void incrementInstance() {
        instanceCount++;
        staticCount++; // 实例方法可以访问静态变量
    }
    
    // 静态方法
    public static int getStaticCount() {
        return staticCount;
    }
    
    // 实例方法
    public int getInstanceCount() {
        return instanceCount;
    }
}

// 使用示例
Counter.incrementStatic(); // 直接通过类名调用静态方法
System.out.println("静态计数：" + Counter.getStaticCount()); // 输出：静态计数：1

Counter counter = new Counter();
counter.incrementInstance(); // 通过对象调用实例方法
System.out.println("实例计数：" + counter.getInstanceCount()); // 输出：实例计数：1
System.out.println("静态计数：" + Counter.getStaticCount()); // 输出：静态计数：2
```

<a id="9"></a>
## 9 . 方法的作用域

<a id="9.1"></a>
### 9.1 局部变量

方法内部声明的变量称为局部变量，只在方法内部有效。

<a id="9.2"></a>
### 9.2 作用域示例

```java
public void method() {
    int localVariable = 10; // 局部变量
    if (localVariable > 5) {
        int innerVariable = 20; // 局部变量，只在 if 块内有效
        System.out.println(innerVariable);
    }
    // System.out.println(innerVariable); // 编译错误，innerVariable 超出作用域
    System.out.println(localVariable); // 正确，localVariable 在方法内有效
}
```

<a id="10"></a>
## 10 . 常见问题与解决方案

<a id="10.1"></a>
### 10.1 方法未定义返回值

**问题描述**：有返回值的方法缺少 return 语句。

**解决方案**：确保所有代码路径都有 return 语句。

```java
// 错误示例
public int getValue(boolean flag) {
    if (flag) {
        return 1;
    }
    // 缺少 return 语句
}

// 正确示例
public int getValue(boolean flag) {
    if (flag) {
        return 1;
    }
    return 0;
}
```

<a id="10.2"></a>
### 10.2 参数类型不匹配

**问题描述**：调用方法时传入的参数类型与方法定义不匹配。

**解决方案**：确保传入的参数类型与方法定义一致，或进行适当的类型转换。

<a id="10.3"></a>
### 10.3 方法重载冲突

**问题描述**：定义的重载方法参数列表无法区分。

**解决方案**：确保重载方法的参数列表有明显区别。

```java
// 错误示例（仅返回值类型不同，不是有效的重载）
public int add(int a, int b) {
    return a + b;
}

public double add(int a, int b) { // 编译错误
    return a + b;
}

// 正确示例（参数类型不同）
public int add(int a, int b) {
    return a + b;
}

public double add(double a, double b) {
    return a + b;
}
```

<a id="10.4"></a>
### 10.4 递归方法栈溢出

**问题描述**：递归方法没有正确的终止条件，导致栈溢出。

**解决方案**：确保递归方法有明确的终止条件。

```java
// 错误示例（无限递归）
public int factorial(int n) {
    return n * factorial(n - 1);
}

// 正确示例
public int factorial(int n) {
    if (n <= 1) {
        return 1; // 终止条件
    }
    return n * factorial(n - 1);
}
```

<a id="11"></a>
## 11 . 最佳实践

<a id="11.1"></a>
### 11.1 方法设计原则

1. **单一职责**：一个方法只做一件事
2. **见名知意**：方法名应清晰表达其功能
3. **参数合理**：参数个数不宜过多，一般不超过 5 个
4. **返回值明确**：返回值类型应清晰表达方法的结果
5. **异常处理**：适当处理可能的异常情况

<a id="11.2"></a>
### 11.2 代码风格

1. **缩进**：使用 4 个空格或 1 个制表符进行缩进
2. **命名**：方法名使用小驼峰命名法
3. **注释**：为复杂方法添加注释，说明其功能、参数和返回值
4. **空行**：在方法之间添加空行，提高可读性

<a id="11.3"></a>
### 11.3 性能优化

1. **避免频繁创建对象**：在方法内部避免频繁创建临时对象
2. **减少参数传递**：对于大对象，考虑使用引用传递
3. **合理使用静态方法**：对于无状态的工具方法，使用静态方法
4. **避免深度递归**：对于复杂问题，考虑使用迭代替代递归

<a id="12"></a>
## 12 . 总结

<a id="12.1"></a>
### 12.1 核心概念

- **方法**：封装特定功能的代码块
- **方法重载**：同名方法不同参数列表
- **参数传递**：Java 使用值传递
- **返回值**：方法执行的结果
- **静态方法**：属于类的方法
- **实例方法**：属于对象的方法

<a id="12.2"></a>
### 12.2 应用场景

- **代码复用**：将重复的逻辑封装成方法
- **功能模块化**：将复杂功能分解为多个方法
- **提高可读性**：通过方法名清晰表达代码功能
- **便于维护**：修改方法实现不影响调用方

<a id="12.3"></a>
### 12.3 个人实践总结

- 遵循单一职责原则，一个方法只做一件事
- 使用有意义的方法名，提高代码可读性
- 合理使用方法重载，提供多种参数组合
- 注意参数传递的特性，避免意外修改原始数据
- 为复杂方法添加适当的注释
- 合理使用静态方法和实例方法
- 确保方法有明确的返回值和终止条件