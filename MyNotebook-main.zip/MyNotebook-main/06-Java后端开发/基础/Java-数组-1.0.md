<a id="title"></a>
# Java 数组

> fanquanpp 的个人学习笔记

最新更新时间：2026-04-05 22:00:00

<a id="1"></a>
## 1 引言

数组是 Java 中用于存储同一种数据类型多个元素的基本数据结构，是编程中常用的数据组织方式。

<a id="2"></a>
## 2 目录

- [1. 数组的概念](#1-数组的概念)
- [2. 数组的声明和初始化](#2-数组的声明和初始化)
- [3. 数组的特点](#3-数组的特点)
- [4. 数组的操作](#4-数组的操作)
- [5. 数组常见异常](#5-数组常见异常)
- [6. 二维数组](#6-二维数组)
- [7. 常用算法](#7-常用算法)
- [8. Arrays 工具类常用方法](#8-arrays 工具类常用方法)
- [9. 数组的内存结构](#9-数组的内存结构)
- [10. 常见问题与解决方案](#10-常见问题与解决方案)
- [11. 总结与最佳实践](#11-总结与最佳实践)

<a id="3"></a>
## 3 . 数组的概念

- 数组是存储同一种数据类型多个元素的集合
- 数组中的元素在内存中是连续存储的
- 数组通过索引访问元素，索引从 0 开始

<a id="4"></a>
## 4 . 数组的声明和初始化

<a id="4.1"></a>
### 4.1 静态初始化（声明时直接赋值）

```java
数据类型[] 数组名 = {元素 1, 元素 2, 元素 3, ...};
// 例如：int[] arr = {1, 2, 3, 4, 5};
```

<a id="4.2"></a>
### 4.2 动态初始化（先指定长度，后赋值）

```java
数据类型[] 数组名 = new 数据类型[数组长度];
// 例如：int[] arr = new int[5];
```

<a id="4.3"></a>
### 4.3 其他声明方式

```java
数据类型 数组名[] = new 数据类型[数组长度];
// 例如：int arr[] = new int[5];
```

<a id="5"></a>
## 5 . 数组的特点

- 数组长度固定不变
- 数组中的每个元素都有默认值
    * 整数类型：0
    * 浮点类型：0.0
    * 字符类型：'\u0000'(Unicode 编码的第一个字符，即空字符)
    * 布尔类型：false
    * 引用类型：null
- 数组有 length 属性，可以获取数组长度

<a id="6"></a>
## 6 . 数组的操作

<a id="6.1"></a>
### 6.1 访问数组元素

```java
语法：数组名[索引]
// 例如：arr[0] 表示访问数组第一个元素
```

<a id="6.2"></a>
### 6.2 修改数组元素

```java
语法：数组名[索引] = 新值;
// 例如：arr[0] = 10;
```

<a id="6.3"></a>
### 6.3 遍历数组

**使用 for 循环：**

```java
for(int i=0; i<arr.length; i++) {
    System.out.println(arr[i]);
}
```

**使用增强 for 循环（for-each）：**

```java
for(数据类型 变量名 : 数组名) {
    System.out.println(变量名);
}
```

<a id="7"></a>
## 7 . 数组常见异常

- **ArrayIndexOutOfBoundsException**：数组索引越界异常
  当访问了不存在的索引时发生

<a id="8"></a>
## 8 . 二维数组

<a id="8.1"></a>
### 8.1 概念

- 二维数组本质上是一个数组，其元素又是一个一维数组

<a id="8.2"></a>
### 8.2 初始化

```java
// 静态初始化：
int[][] arr = {{1,2},{3,4},{5,6}};

// 动态初始化：
int[][] arr = new int[3][4];
```

<a id="8.3"></a>
### 8.3 访问二维数组元素

```java
语法：数组名[行索引][列索引]
// 例如：arr[0][0] 表示访问第一行第一列的元素
```

<a id="8.4"></a>
### 8.4 遍历二维数组

```java
// 使用嵌套 for 循环
for (int i = 0; i < arr.length; i++) {
    for (int j = 0; j < arr[i].length; j++) {
        System.out.print(arr[i][j] + " ");
    }
    System.out.println();
}

// 使用嵌套增强 for 循环
for (int[] row : arr) {
    for (int element : row) {
        System.out.print(element + " ");
    }
    System.out.println();
}
```

<a id="9"></a>
## 9 . 常用算法

<a id="9.1"></a>
### 9.1 数组排序

<a id="9.1.1"></a>
#### 9.1.1 冒泡排序

```java
public static void bubbleSort(int[] arr) {
    for (int i = 0; i < arr.length - 1; i++) {
        for (int j = 0; j < arr.length - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                // 交换元素
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
```

<a id="9.1.2"></a>
#### 9.1.2 选择排序

```java
public static void selectionSort(int[] arr) {
    for (int i = 0; i < arr.length - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < arr.length; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // 交换元素
        int temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}
```

<a id="9.1.3"></a>
#### 9.1.3 使用 Arrays.sort() 方法

```java
import java.util.Arrays;

public static void sortArray(int[] arr) {
    Arrays.sort(arr);
}
```

<a id="9.2"></a>
### 9.2 数组查找

<a id="9.2.1"></a>
#### 9.2.1 线性查找

```java
public static int linearSearch(int[] arr, int target) {
    for (int i = 0; i < arr.length; i++) {
        if (arr[i] == target) {
            return i; // 返回目标元素的索引
        }
    }
    return -1; // 未找到目标元素
}
```

<a id="9.2.2"></a>
#### 9.2.2 二分查找（针对有序数组）

```java
public static int binarySearch(int[] arr, int target) {
    int left = 0;
    int right = arr.length - 1;
    
    while (left <= right) {
        int mid = left + (right - left) / 2;
        
        if (arr[mid] == target) {
            return mid; // 找到目标元素
        } else if (arr[mid] < target) {
            left = mid + 1; // 目标在右半部分
        } else {
            right = mid - 1; // 目标在左半部分
        }
    }
    
    return -1; // 未找到目标元素
}
```

<a id="9.3"></a>
### 9.3 数组操作

<a id="9.3.1"></a>
#### 9.3.1 数组复制

```java
// 使用 Arrays.copyOf() 方法
int[] newArr = Arrays.copyOf(arr, newLength);

// 使用 System.arraycopy() 方法
int[] newArr = new int[newLength];
System.arraycopy(arr, 0, newArr, 0, Math.min(arr.length, newLength));
```

<a id="9.3.2"></a>
#### 9.3.2 数组反转

```java
public static void reverseArray(int[] arr) {
    int left = 0;
    int right = arr.length - 1;
    
    while (left < right) {
        // 交换元素
        int temp = arr[left];
        arr[left] = arr[right];
        arr[right] = temp;
        
        left++;
        right--;
    }
}
```

<a id="10"></a>
## 10 . Arrays 工具类常用方法

| 方法 | 描述 | 示例 |
| :--- | :--- | :--- |
| `Arrays.toString(arr)` | 将数组转换为字符串 | `System.out.println(Arrays.toString(arr));` |
| `Arrays.sort(arr)` | 对数组进行排序 | `Arrays.sort(arr);` |
| `Arrays.copyOf(arr, newLength)` | 复制数组 | `int[] newArr = Arrays.copyOf(arr, 10);` |
| `Arrays.equals(arr1, arr2)` | 比较两个数组是否相等 | `boolean isEqual = Arrays.equals(arr1, arr2);` |
| `Arrays.fill(arr, value)` | 填充数组 | `Arrays.fill(arr, 0);` |
| `Arrays.binarySearch(arr, target)` | 二分查找 | `int index = Arrays.binarySearch(arr, 5);` |

<a id="11"></a>
## 11 . 数组的内存结构

<a id="11.1"></a>
### 11.1 一维数组的内存结构

- **数组引用**：存储在栈内存中，指向堆内存中的数组对象
- **数组元素**：存储在堆内存中，连续分配空间

**示例：**
```java
int[] arr = new int[3];
arr[0] = 10;
arr[1] = 20;
arr[2] = 30;
```

<a id="11.2"></a>
### 11.2 二维数组的内存结构

- **数组引用**：存储在栈内存中
- **外层数组**：存储在堆内存中，元素是指向内层数组的引用
- **内层数组**：存储在堆内存中，元素是具体的值

**示例：**
```java
int[][] arr = new int[2][3];
arr[0][0] = 1;
arr[0][1] = 2;
arr[0][2] = 3;
arr[1][0] = 4;
arr[1][1] = 5;
arr[1][2] = 6;
```

<a id="12"></a>
## 12 . 常见问题与解决方案

<a id="12.1"></a>
### 12.1 数组索引越界异常

**问题描述：** 访问数组时出现 `ArrayIndexOutOfBoundsException` 异常。

**原因分析：** 访问了不存在的数组索引，索引超出了数组的范围。

**解决方案：**
- 确保索引在有效范围内（0 到 array.length - 1）
- 使用循环时，确保循环条件正确
- 避免硬编码索引值

<a id="12.2"></a>
### 12.2 空指针异常

**问题描述：** 操作数组时出现 `NullPointerException` 异常。

**原因分析：** 数组引用为 null，或二维数组中的内层数组为 null。

**解决方案：**
- 确保数组已经初始化
- 检查数组引用是否为 null
- 对于二维数组，确保内层数组也已初始化

<a id="12.3"></a>
### 12.3 数组长度固定问题

**问题描述：** 数组长度固定，无法动态调整。

**原因分析：** Java 中的数组长度在创建时确定，无法修改。

**解决方案：**
- 使用 `Arrays.copyOf()` 方法创建新数组
- 使用集合类（如 ArrayList）代替数组
- 预估数组长度，避免频繁扩容

<a id="12.4"></a>
### 12.4 数组排序性能问题

**问题描述：** 对大型数组排序时性能较差。

**原因分析：** 使用了效率较低的排序算法。

**解决方案：**
- 使用 `Arrays.sort()` 方法，它实现了高效的排序算法
- 对于基本数据类型，`Arrays.sort()` 使用双轴快速排序
- 对于对象类型，`Arrays.sort()` 使用归并排序

<a id="13"></a>
## 13 . 总结与最佳实践

<a id="13.1"></a>
### 13.1 核心概念

- **数组**：存储同一种数据类型多个元素的集合
- **索引**：数组元素的位置，从 0 开始
- **长度**：数组中元素的个数，通过 `length` 属性获取
- **初始化**：静态初始化和动态初始化
- **遍历**：使用 for 循环或增强 for 循环

<a id="13.2"></a>
### 13.2 最佳实践

1. **数组使用**
   - 根据实际需求选择合适的数组类型
   - 合理预估数组长度，避免频繁扩容
   - 使用增强 for 循环简化遍历代码
   - 注意数组索引的范围，避免越界异常

2. **性能优化**
   - 对于大型数组，使用 `Arrays.sort()` 进行排序
   - 避免在循环中频繁创建数组
   - 合理使用 `Arrays.copyOf()` 方法
   - 对于需要频繁修改大小的场景，考虑使用集合类

3. **代码风格**
   - 数组声明使用 `数据类型[] 数组名` 的形式
   - 为数组添加适当的注释
   - 使用有意义的数组名
   - 保持代码缩进一致

4. **常见场景**
   - 使用数组存储固定长度的数据
   - 使用二维数组存储表格数据
   - 使用数组实现简单的排序和查找算法
   - 使用 `Arrays` 工具类简化数组操作

<a id="13.3"></a>
### 13.3 个人实践总结
- 根据实际需求选择合适的数组类型和长度
- 使用增强 for 循环简化数组遍历
- 注意数组索引的范围，避免越界异常
- 利用 Arrays 工具类简化数组操作
- 对于大型数组，使用 Arrays.sort() 进行排序
- 对于需要频繁修改大小的场景，考虑使用集合类