<a id="title"></a>
# Git 环境配置与初始化

> fanquanpp 的个人学习笔记

最新更新时间：2026-04-05

<a id="1"></a>
## 1 目录

- [1. 环境配置](#1-环境配置)
    - [1.1 全局配置](#11-全局配置)
    - [1.2 本地配置](#12-本地配置)
    - [1.3 配置验证](#13-配置验证)
    - [1.4 高级配置](#14-高级配置)
- [2. 仓库初始化](#2-仓库初始化)
    - [2.1 初始化本地仓库](#21-初始化本地仓库)
    - [2.2 克隆远程仓库](#22-克隆远程仓库)
- [3. 配置文件位置](#3-配置文件位置)
- [4. 常见配置问题与解决方案](#4-常见配置问题与解决方案)
- [5. 总结](#5-总结)

<a id="2"></a>
## 2 . 环境配置

在使用 Git 之前，需要进行基本的环境配置，主要包括设置用户名、邮箱等信息，这些信息会被记录在每次提交中。

<a id="2.1"></a>
### 2.1 全局配置

全局配置会应用到所有 Git 仓库，适合设置通用的信息：

```bash
# 设置用户名（全局）
git config --global user.name "你的用户名"

# 设置邮箱（全局）
git config --global user.email "你的邮箱"

# 设置默认分支名称
git config --global init.defaultBranch main

# 解决 Windows 下中文文件名乱码问题
git config --global core.quotepath false

# 设置默认编辑器
git config --global core.editor "code --wait"

# 设置差异比较工具
git config --global diff.tool vscode
git config --global difftool.vscode.cmd "code --wait --diff $LOCAL $REMOTE"

# 设置合并工具
git config --global merge.tool vscode
git config --global mergetool.vscode.cmd "code --wait $MERGED"

# 设置自动换行处理
git config --global core.autocrlf true  # Windows 系统
git config --global core.autocrlf input  # Mac/Linux 系统

# 设置提交时自动删除尾部空格
git config --global core.trimwhitespace true
```

<a id="2.2"></a>
### 2.2 本地配置

本地配置仅应用于当前仓库，适合设置特定于项目的信息：

```bash
# 设置用户名（仅当前仓库）
git config user.name "你的用户名"

# 设置邮箱（仅当前仓库）
git config user.email "你的邮箱"
```

<a id="2.3"></a>
### 2.3 配置验证

配置完成后，可以通过以下命令验证配置是否成功：

```bash
# 查看所有配置
git config --list

# 查看特定配置
git config user.name
git config user.email
```

<a id="2.4"></a>
### 2.4 高级配置

```bash
# 配置 Git 缓存大小
git config --global core.packedGitLimit 512m
git config --global core.packedGitWindowSize 512m

# 配置 Git 压缩级别
git config --global core.compression 9

# 配置 Git 并行操作数量
git config --global pack.threads 4

# 配置 Git 远程操作超时
git config --global http.postBuffer 524288000

# 设置常用别名
git config --global alias.st status
git config --global alias.ci commit
git config --global alias.co checkout
git config --global alias.br branch
git config --global alias.unstage "reset HEAD --"
git config --global alias.last "log -1 --stat"
git config --global alias.logg "log --oneline --graph --all"
git config --global alias.df "diff"
git config --global alias.dfc "diff --cached"
git config --global alias.cp "cherry-pick"
```

<a id="3"></a>
## 3 . 仓库初始化

<a id="3.1"></a>
### 3.1 初始化本地仓库

在当前目录初始化一个新的 Git 仓库：

```bash
# 进入项目目录
cd <项目目录>

# 初始化 Git 仓库
git init
```

执行后，会在当前目录创建一个 `.git` 文件夹，用于存储 Git 相关的信息。

<a id="3.2"></a>
### 3.2 克隆远程仓库

从远程服务器克隆一个已有的仓库：

```bash
# 克隆默认分支
git clone <仓库地址>

# 克隆指定分支
git clone -b <分支名> <仓库地址>

# 克隆指定深度（只获取最近的 N 个提交）
git clone --depth 1 <仓库地址>  # 只获取最近 1 个提交

# 克隆时指定目录名
git clone <仓库地址> <目录名>

# 克隆所有分支
git clone --mirror <仓库地址>  # 通常用于创建镜像仓库
```

<a id="4"></a>
## 4 . 配置文件位置

Git 的配置文件存储在以下位置：

- **全局配置**：`~/.gitconfig`（Windows 系统为 `C:\Users\用户名\.gitconfig`）
- **本地配置**：`.git/config`（位于每个 Git 仓库的 `.git` 目录中）
- **系统配置**：`/etc/gitconfig`（Windows 系统为 `C:\Program Files\Git\etc\gitconfig`）

<a id="5"></a>
## 5 . 常见配置问题与解决方案

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 中文文件名乱码 | Git 默认使用 ASCII 编码处理文件名 | 执行 `git config --global core.quotepath false` |
| 换行符不一致 | 不同操作系统的换行符标准不同 | 根据系统类型设置 `core.autocrlf` |
| 编辑器配置错误 | 默认编辑器设置不当 | 使用 `git config --global core.editor` 设置合适的编辑器 |
| 远程操作超时 | 网络连接不稳定或文件过大 | 增加 `http.postBuffer` 值 |

<a id="6"></a>
## 6 . 总结

Git 的环境配置和仓库初始化是使用 Git 的基础步骤。通过合理的配置，可以提高 Git 的使用效率，避免常见问题。

- **全局配置**：适合设置通用信息，如用户名、邮箱、编辑器等
- **本地配置**：适合设置特定于项目的信息
- **仓库初始化**：可以通过 `git init` 创建新仓库，或通过 `git clone` 克隆现有仓库
- **配置验证**：使用 `git config --list` 查看当前配置

正确的环境配置是使用 Git 的良好开端，为后续的版本控制操作打下基础。