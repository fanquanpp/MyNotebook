<a id="title"></a>
# Git 基本操作

> fanquanpp 的个人学习笔记

最新更新时间：2026-04-05

<a id="1"></a>
## 1 目录

- [1. 状态管理](#1-状态管理)
- [2. 暂存与提交](#2-暂存与提交)
- [3. 查看历史记录](#3-查看历史记录)
- [4. 差异比较](#4-差异比较)
- [5. 撤销操作](#5-撤销操作)
    - [5.1 工作区撤销](#51-工作区撤销)
    - [5.2 暂存区撤销](#52-暂存区撤销)
    - [5.3 提交撤销](#53-提交撤销)
- [6. 实用技巧](#6-实用技巧)
    - [6.1 忽略文件](#61-忽略文件)
    - [6.2 别名设置](#62-别名设置)
- [7. 完整操作流程](#7-完整操作流程)
    - [7.1 新项目初始化与推送](#71-新项目初始化与推送)
    - [7.2 日常开发流程](#72-日常开发流程)
- [8. 总结](#8-总结)

<a id="2"></a>
## 2 . 状态管理

状态管理是 Git 最基本的操作之一，用于查看当前仓库的状态：

```bash
# 查看当前仓库状态
git status

# 查看详细状态（包括忽略的文件）
git status --ignored

# 以短格式查看状态
git status -s  # 或 git status --short
```

状态输出说明：
- `A`：新添加到暂存区的文件
- `M`：修改过的文件
- `D`：删除的文件
- `??`：未跟踪的文件
- `!!`：被忽略的文件

<a id="3"></a>
## 3 . 暂存与提交

<a id="3.1"></a>
### 3.1 暂存操作

暂存操作将工作区的修改添加到暂存区：

```bash
# 添加单个文件到暂存区
git add <文件名>

# 添加所有文件到暂存区
git add .

# 添加指定类型的文件
git add *.md

# 添加目录到暂存区
git add <目录名>/

# 从暂存区移除文件
git reset HEAD <文件名>

# 从暂存区中移除文件但保留工作区文件
git rm --cached <文件名>
```

<a id="3.2"></a>
### 3.2 提交操作

提交操作将暂存区的内容提交到本地仓库：

```bash
# 提交到本地仓库
git commit -m "提交说明"

# 提交时自动添加修改的文件
git commit -am "提交说明"

# 修改最近一次提交信息
git commit --amend -m "新的提交说明"

# 向最近一次提交添加更多修改
git add <文件名>
git commit --amend --no-edit
```

<a id="4"></a>
## 4 . 查看历史记录

查看提交历史是了解项目变更的重要方式：

```bash
# 查看提交历史
git log

# 查看简洁的提交历史
git log --oneline

# 查看指定数量的提交历史
git log -n 5

# 查看提交历史并显示每次提交的变更内容
git log -p

# 查看指定文件的提交历史
git log --oneline <文件名>

# 查看指定作者的提交历史
git log --author="作者名"

# 查看指定时间段的提交历史
git log --since="2026-04-01" --until="2026-04-30"

# 查看分支合并历史
git log --graph --oneline
```

<a id="5"></a>
## 5 . 差异比较

差异比较用于查看文件的变化：

```bash
# 查看工作区与暂存区的差异
git diff

# 查看暂存区与本地仓库的差异
git diff --cached

# 查看工作区与指定提交的差异
git diff <提交哈希>

# 查看两次提交之间的差异
git diff <提交 1> <提交 2>

# 查看指定文件在两次提交之间的差异
git diff <提交 1> <提交 2> <文件名>
```

<a id="6"></a>
## 6 . 撤销操作

<a id="6.1"></a>
### 6.1 工作区撤销

撤销工作区中的修改：

```bash
# 撤销工作区中单个文件的修改
git checkout -- <文件名>

# 撤销工作区中所有文件的修改
git checkout .
```

<a id="6.2"></a>
### 6.2 暂存区撤销

撤销暂存区中的修改：

```bash
# 撤销暂存区中单个文件的修改
git reset HEAD <文件名>

# 撤销暂存区中所有文件的修改
git reset HEAD .
```

<a id="6.3"></a>
### 6.3 提交撤销

撤销已经提交的修改：

```bash
# 撤销最近一次提交（保留修改在暂存区）
git reset --soft HEAD~1

# 撤销最近一次提交（保留修改在工作区）
git reset --mixed HEAD~1  # 或 git reset HEAD~1

# 撤销最近一次提交（丢弃所有修改）
git reset --hard HEAD~1

# 撤销指定提交（保留之后的修改）
git reset --soft <提交哈希>

# 撤销指定提交（丢弃所有修改）
git reset --hard <提交哈希>

# 撤销指定提交（创建新的提交）
git revert <提交哈希>
```

<a id="7"></a>
## 7 . 实用技巧

<a id="7.1"></a>
### 7.1 忽略文件

创建 `.gitignore` 文件，添加需要忽略的文件或目录：

```gitignore
# 忽略 node_modules 目录
node_modules/

# 忽略日志文件
*.log

# 忽略编译产物
dist/
build/

# 忽略环境变量文件
.env
.env.local

# 忽略 IDE 配置文件
.vscode/
.idea/

# 忽略操作系统文件
.DS_Store
Thumbs.db

# 忽略临时文件
*.tmp
*.temp

# 忽略测试覆盖率文件
coverage/

# 忽略打包文件
*.zip
*.tar.gz
```

<a id="7.2"></a>
### 7.2 别名设置

设置常用命令的别名，提高操作效率：

```bash
# 设置常用别名
git config --global alias.st status
git config --global alias.ci commit
git config --global alias.co checkout
git config --global alias.br branch
git config --global alias.unstage "reset HEAD --"
git config --global alias.last "log -1 --stat"
git config --global alias.logg "log --oneline --graph --all"
git config --global alias.df "diff"
git config --global alias.dfc "diff --cached"
git config --global alias.cp "cherry-pick"
```

<a id="8"></a>
## 8 . 完整操作流程

<a id="8.1"></a>
### 8.1 新项目初始化与推送

```bash
# 1. 全局配置（仅第一次）
git config --global user.name "用户名称"
git config --global user.email "GitHub 邮箱地址"

# 2. 新建/进入项目文件夹并初始化
mkdir my-project
cd my-project
# 2-1. 初始化 Git 仓库
git init

# 3. 写代码，然后提交
git add .
git commit -m "初始化项目"

# 4. 关联远程仓库（替换为你的地址）
git remote add origin https://github.com/xxx/my-project.git

# 5. 首次推送（带 -u）
git push -u origin main
```

<a id="8.2"></a>
### 8.2 日常开发流程

```bash
# --- 日常开发 --- #
# 1. 查看修改状态
git status

# 2. 添加修改
git add .

# 3. 提交修改
git commit -m "新增了登录功能"

# 4. 拉取远程更新（防止冲突）
git pull

# 5. 推送到远程仓库
git push
```

<a id="9"></a>
## 9 . 总结

Git 的基本操作是使用 Git 的核心，掌握这些操作可以有效地管理代码的版本和变更。

- **状态管理**：使用 `git status` 查看仓库状态
- **暂存与提交**：使用 `git add` 和 `git commit` 管理代码变更
- **查看历史**：使用 `git log` 查看提交历史
- **差异比较**：使用 `git diff` 查看文件变化
- **撤销操作**：使用 `git checkout`、`git reset` 和 `git revert` 撤销修改
- **实用技巧**：使用 `.gitignore` 忽略文件，设置别名提高效率

通过熟练掌握这些基本操作，可以为后续的分支管理、远程操作等高级功能打下基础。