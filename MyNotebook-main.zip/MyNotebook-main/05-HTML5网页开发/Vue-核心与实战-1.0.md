<!--
文件名称：Vue-学习笔记
原名称：无
用途描述：介绍 Vue.js 基础核心概念、组件化开发、Vuex 状态管理及实战案例（Vue-Todos）。
创建/更新：2026-04-05
-->

# Vue 学习笔记（Vue.js Learning Notes）

Vue.js 是一套用于构建用户界面的渐进式 JavaScript 框架。本笔记基于实战项目 `vue-todos` 总结核心知识点。

## 1. 核心概念

- **渐进式框架**：可以自底向上逐层应用。
- **声明式渲染**：基于简洁的模板语法来声明式地将数据渲染进 DOM。
- **组件化**：Vue 的核心思想。将页面拆分为独立、可复用的组件。
- **响应式系统**：数据模型（Data）是普通的 JavaScript 对象，修改它们时视图会进行自动更新。

## 2. 语法基础

### 2.1 模板语法
- **插值**：`{{ message }}`。
- **指令**：`v-bind` (:), `v-on` (@), `v-if`, `v-for`, `v-model`。

```html
<div id="app">
  <p>{{ message }}</p>
  <button @click="reverseMessage">反转消息</button>
</div>
```

### 2.2 组件定义
- **单文件组件 (SFC)**：`.vue` 文件，包含 `<template>`, `<script>`, `<style>`。

```vue
<template>
  <div class="todo-item">{{ title }}</div>
</template>

<script>
export default {
  props: ['title']
}
</script>

<style scoped>
.todo-item { color: blue; }
</style>
```

### 2.3 生命周期钩子
- `created`：实例创建完成。
- `mounted`：DOM 挂载完成。
- `updated`：数据更新。
- `destroyed`：实例销毁。

## 3. 实战应用

### 3.1 Vue-Todos 项目案例
- **功能**：新增任务、删除任务、标记完成、过滤状态。
- **状态管理**：使用 Vuex 统一管理 Todos 数据流。

```javascript
// store/index.js (Vuex)
export default new Vuex.Store({
  state: {
    todos: []
  },
  mutations: {
    ADD_TODO(state, todo) {
      state.todos.push(todo);
    }
  }
});
```

## 4. 最佳实践

- **组件通信**：
    - 父传子：`props`。
    - 子传父：`$emit`。
    - 兄弟/全局：`Vuex` 或 `Event Bus`。
- **代码规范**：
    - 坚持为 `v-for` 提供 `key`。
    - 组件名为多个单词（如 `TodoItem` 而非 `Item`）。
    - 样式使用 `scoped` 防止污染。

## 5. 延伸阅读

- [Vue.js 官方文档](https://vuejs.org/) <!-- nofollow -->
- [vue-todos 实战项目教程](https://github.com/liangxiaojuan/vue-todos) <!-- nofollow -->

## 6. 更新日志

- **2026-04-05**：初始版本，整理 Vue 核心与实战应用。
